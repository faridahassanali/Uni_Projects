﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;

namespace STS
{
    public partial class newdatastudent : Form
    {
        string connstring = ConfigurationManager.ConnectionStrings["condb"].ConnectionString;
        public newdatastudent()
        {
            InitializeComponent();
        }

        private void txtGrade_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            txtStudentName.Text = "";
            txtStudentAddress.Text = "";
            txtGrade.Text = "";
            txtClass.Text = "";
            txtPhoneNumber.Text = "";
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
          
            using (SqlConnection oonnn = new SqlConnection(connstring))
            {
                oonnn.Open();
                string queryy = "INSERT INTO Students ([Name], [Address], [Grade], [Class],[Phone number of parent]) " +
                             "VALUES (@StudentName, @StudentAddress, @Grade, @Class, @PhoneNumber)";
                using (SqlCommand mmddd = new SqlCommand(queryy, oonnn))
                {
                    mmddd.Parameters.AddWithValue("@StudentName", txtStudentName.Text);
                    mmddd.Parameters.AddWithValue("@StudentAddress", txtStudentAddress.Text);
                    mmddd.Parameters.AddWithValue("@Grade", txtGrade.Text);
                    mmddd.Parameters.AddWithValue("@Class", txtClass.Text);
                    mmddd.Parameters.AddWithValue("@PhoneNumber", txtPhoneNumber.Text);

                    mmddd.ExecuteNonQuery();
                    MessageBox.Show("Record Added Successfully");
                }
            }

        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
            students frm25= new students();
            frm25.Show();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
