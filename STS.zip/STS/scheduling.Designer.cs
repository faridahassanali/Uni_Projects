﻿namespace STS
{
    partial class scheduling
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.btnRestore = new System.Windows.Forms.Button();
            this.btnMinimize = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnNew = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.schedulingg = new System.Windows.Forms.GroupBox();
            this.txtDeparture2 = new System.Windows.Forms.TextBox();
            this.txtArrival2 = new System.Windows.Forms.TextBox();
            this.txtDeparture1 = new System.Windows.Forms.TextBox();
            this.txtArrival1 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtName2turn = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtAssgSupervisor2 = new System.Windows.Forms.TextBox();
            this.txtName1turn = new System.Windows.Forms.TextBox();
            this.txtAssgDriver2 = new System.Windows.Forms.TextBox();
            this.txtItinerary = new System.Windows.Forms.TextBox();
            this.txtTurns = new System.Windows.Forms.TextBox();
            this.txtBusNumber2 = new System.Windows.Forms.TextBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnBack = new System.Windows.Forms.Button();
            this.schedulingg.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnRestore
            // 
            this.btnRestore.FlatAppearance.BorderSize = 0;
            this.btnRestore.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnRestore.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRestore.Image = global::STS.Properties.Resources.Screenshot_2024_05_05_234310;
            this.btnRestore.Location = new System.Drawing.Point(1236, 12);
            this.btnRestore.Name = "btnRestore";
            this.btnRestore.Size = new System.Drawing.Size(30, 30);
            this.btnRestore.TabIndex = 2;
            this.toolTip1.SetToolTip(this.btnRestore, "Restore");
            this.btnRestore.UseVisualStyleBackColor = true;
            // 
            // btnMinimize
            // 
            this.btnMinimize.FlatAppearance.BorderSize = 0;
            this.btnMinimize.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnMinimize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMinimize.Image = global::STS.Properties.Resources.Screenshot_2024_05_05_234300;
            this.btnMinimize.Location = new System.Drawing.Point(1272, 12);
            this.btnMinimize.Name = "btnMinimize";
            this.btnMinimize.Size = new System.Drawing.Size(30, 30);
            this.btnMinimize.TabIndex = 2;
            this.toolTip1.SetToolTip(this.btnMinimize, "Minimize");
            this.btnMinimize.UseVisualStyleBackColor = true;
            // 
            // btnClose
            // 
            this.btnClose.FlatAppearance.BorderSize = 0;
            this.btnClose.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Red;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClose.Image = global::STS.Properties.Resources.Screenshot_2024_05_05_2342472;
            this.btnClose.Location = new System.Drawing.Point(1308, 12);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(30, 30);
            this.btnClose.TabIndex = 1;
            this.toolTip1.SetToolTip(this.btnClose, "Close");
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnNew
            // 
            this.btnNew.FlatAppearance.BorderSize = 0;
            this.btnNew.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNew.Image = global::STS.Properties.Resources.add_125912453;
            this.btnNew.Location = new System.Drawing.Point(128, 3);
            this.btnNew.Name = "btnNew";
            this.btnNew.Size = new System.Drawing.Size(77, 60);
            this.btnNew.TabIndex = 12;
            this.toolTip1.SetToolTip(this.btnNew, "New");
            this.btnNew.UseVisualStyleBackColor = true;
            this.btnNew.Click += new System.EventHandler(this.btnNew_Click);
            // 
            // btnSave
            // 
            this.btnSave.FlatAppearance.BorderSize = 0;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSave.Image = global::STS.Properties.Resources.Adobe_Express_2024_05_06_15_174;
            this.btnSave.Location = new System.Drawing.Point(39, 3);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(77, 60);
            this.btnSave.TabIndex = 0;
            this.toolTip1.SetToolTip(this.btnSave, "Save Data");
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // schedulingg
            // 
            this.schedulingg.BackColor = System.Drawing.SystemColors.ControlLight;
            this.schedulingg.Controls.Add(this.txtDeparture2);
            this.schedulingg.Controls.Add(this.txtArrival2);
            this.schedulingg.Controls.Add(this.txtDeparture1);
            this.schedulingg.Controls.Add(this.txtArrival1);
            this.schedulingg.Controls.Add(this.label12);
            this.schedulingg.Controls.Add(this.label11);
            this.schedulingg.Controls.Add(this.label10);
            this.schedulingg.Controls.Add(this.label7);
            this.schedulingg.Controls.Add(this.txtName2turn);
            this.schedulingg.Controls.Add(this.label5);
            this.schedulingg.Controls.Add(this.txtAssgSupervisor2);
            this.schedulingg.Controls.Add(this.txtName1turn);
            this.schedulingg.Controls.Add(this.txtAssgDriver2);
            this.schedulingg.Controls.Add(this.txtItinerary);
            this.schedulingg.Controls.Add(this.txtTurns);
            this.schedulingg.Controls.Add(this.txtBusNumber2);
            this.schedulingg.Controls.Add(this.panel5);
            this.schedulingg.Controls.Add(this.label2);
            this.schedulingg.Controls.Add(this.label4);
            this.schedulingg.Controls.Add(this.label6);
            this.schedulingg.Controls.Add(this.label3);
            this.schedulingg.Controls.Add(this.label9);
            this.schedulingg.Controls.Add(this.label8);
            this.schedulingg.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.schedulingg.Location = new System.Drawing.Point(26, 152);
            this.schedulingg.Name = "schedulingg";
            this.schedulingg.Size = new System.Drawing.Size(1298, 512);
            this.schedulingg.TabIndex = 21;
            this.schedulingg.TabStop = false;
            // 
            // txtDeparture2
            // 
            this.txtDeparture2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDeparture2.Location = new System.Drawing.Point(970, 368);
            this.txtDeparture2.Name = "txtDeparture2";
            this.txtDeparture2.Size = new System.Drawing.Size(314, 27);
            this.txtDeparture2.TabIndex = 27;
            // 
            // txtArrival2
            // 
            this.txtArrival2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtArrival2.Location = new System.Drawing.Point(901, 310);
            this.txtArrival2.Name = "txtArrival2";
            this.txtArrival2.Size = new System.Drawing.Size(383, 27);
            this.txtArrival2.TabIndex = 26;
            this.txtArrival2.TextChanged += new System.EventHandler(this.txtArrival2_TextChanged);
            // 
            // txtDeparture1
            // 
            this.txtDeparture1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDeparture1.Location = new System.Drawing.Point(312, 390);
            this.txtDeparture1.Name = "txtDeparture1";
            this.txtDeparture1.Size = new System.Drawing.Size(348, 27);
            this.txtDeparture1.TabIndex = 25;
            // 
            // txtArrival1
            // 
            this.txtArrival1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtArrival1.Location = new System.Drawing.Point(237, 310);
            this.txtArrival1.Name = "txtArrival1";
            this.txtArrival1.Size = new System.Drawing.Size(383, 27);
            this.txtArrival1.TabIndex = 24;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(20, 355);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(271, 62);
            this.label12.TabIndex = 23;
            this.label12.Text = "Departure time from \r\nschool for the first turn:";
            this.label12.Click += new System.EventHandler(this.label12_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(691, 362);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(302, 62);
            this.label11.TabIndex = 22;
            this.label11.Text = "Departure time from \r\nschool for the second turn:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(20, 275);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(252, 62);
            this.label10.TabIndex = 21;
            this.label10.Text = "Arrival time to school \r\nfor the first turn:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(639, 275);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(252, 62);
            this.label7.TabIndex = 20;
            this.label7.Text = "Arrival time to school \r\nfor the second turn:";
            // 
            // txtName2turn
            // 
            this.txtName2turn.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtName2turn.Location = new System.Drawing.Point(354, 232);
            this.txtName2turn.Name = "txtName2turn";
            this.txtName2turn.Size = new System.Drawing.Size(456, 27);
            this.txtName2turn.TabIndex = 19;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(20, 197);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(306, 62);
            this.label5.TabIndex = 18;
            this.label5.Text = "Name of students in \r\nsecond turn and Addresses:";
            // 
            // txtAssgSupervisor2
            // 
            this.txtAssgSupervisor2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAssgSupervisor2.Location = new System.Drawing.Point(277, 77);
            this.txtAssgSupervisor2.Name = "txtAssgSupervisor2";
            this.txtAssgSupervisor2.Size = new System.Drawing.Size(383, 27);
            this.txtAssgSupervisor2.TabIndex = 17;
            // 
            // txtName1turn
            // 
            this.txtName1turn.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtName1turn.Location = new System.Drawing.Point(837, 163);
            this.txtName1turn.Name = "txtName1turn";
            this.txtName1turn.Size = new System.Drawing.Size(455, 27);
            this.txtName1turn.TabIndex = 16;
            // 
            // txtAssgDriver2
            // 
            this.txtAssgDriver2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAssgDriver2.Location = new System.Drawing.Point(816, 9);
            this.txtAssgDriver2.Name = "txtAssgDriver2";
            this.txtAssgDriver2.Size = new System.Drawing.Size(385, 27);
            this.txtAssgDriver2.TabIndex = 15;
            // 
            // txtItinerary
            // 
            this.txtItinerary.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtItinerary.Location = new System.Drawing.Point(138, 134);
            this.txtItinerary.Name = "txtItinerary";
            this.txtItinerary.Size = new System.Drawing.Size(383, 27);
            this.txtItinerary.TabIndex = 14;
            this.txtItinerary.TextChanged += new System.EventHandler(this.txtItinerary_TextChanged);
            // 
            // txtTurns
            // 
            this.txtTurns.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTurns.Location = new System.Drawing.Point(901, 83);
            this.txtTurns.Name = "txtTurns";
            this.txtTurns.Size = new System.Drawing.Size(383, 27);
            this.txtTurns.TabIndex = 13;
            this.txtTurns.TextChanged += new System.EventHandler(this.txtLicence_TextChanged);
            // 
            // txtBusNumber2
            // 
            this.txtBusNumber2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBusNumber2.Location = new System.Drawing.Point(189, 18);
            this.txtBusNumber2.Name = "txtBusNumber2";
            this.txtBusNumber2.Size = new System.Drawing.Size(383, 27);
            this.txtBusNumber2.TabIndex = 12;
            this.txtBusNumber2.TextChanged += new System.EventHandler(this.txtBusNumber_TextChanged);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.panel5.Controls.Add(this.btnNew);
            this.panel5.Controls.Add(this.btnSave);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel5.Location = new System.Drawing.Point(3, 443);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1292, 66);
            this.panel5.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(20, 12);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(150, 31);
            this.label2.TabIndex = 0;
            this.label2.Text = "Bus number:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(535, 128);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(275, 62);
            this.label4.TabIndex = 2;
            this.label4.Text = "Name of students in \r\nfirst turn and Addresses:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(676, 77);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(199, 31);
            this.label6.TabIndex = 4;
            this.label6.Text = "Number of turns:";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(20, 128);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(112, 31);
            this.label3.TabIndex = 1;
            this.label3.Text = "Itinerary:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(20, 73);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(236, 31);
            this.label9.TabIndex = 7;
            this.label9.Text = "Assigned supervisor:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(605, 5);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(187, 31);
            this.label8.TabIndex = 6;
            this.label8.Text = "Assigned driver:";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.Highlight;
            this.panel3.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel3.Location = new System.Drawing.Point(1330, 100);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(20, 600);
            this.panel3.TabIndex = 23;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.Highlight;
            this.panel1.Controls.Add(this.btnRestore);
            this.panel1.Controls.Add(this.btnMinimize);
            this.panel1.Controls.Add(this.btnClose);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1350, 100);
            this.panel1.TabIndex = 22;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(733, 59);
            this.label1.TabIndex = 0;
            this.label1.Text = "Welcome to Transportation System";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.Highlight;
            this.panel4.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel4.Location = new System.Drawing.Point(0, 100);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(20, 600);
            this.panel4.TabIndex = 24;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.Highlight;
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(20, 670);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1310, 30);
            this.panel2.TabIndex = 25;
            // 
            // btnBack
            // 
            this.btnBack.FlatAppearance.BorderSize = 0;
            this.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBack.Image = global::STS.Properties.Resources.Adobe_Express_2024_05_06_13_26_17;
            this.btnBack.Location = new System.Drawing.Point(26, 106);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(40, 40);
            this.btnBack.TabIndex = 20;
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // scheduling
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(1350, 700);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.schedulingg);
            this.Controls.Add(this.btnBack);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "scheduling";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "scheduling";
            this.Load += new System.EventHandler(this.scheduling_Load);
            this.schedulingg.ResumeLayout(false);
            this.schedulingg.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.GroupBox schedulingg;
        private System.Windows.Forms.TextBox txtName2turn;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtAssgSupervisor2;
        private System.Windows.Forms.TextBox txtName1turn;
        private System.Windows.Forms.TextBox txtAssgDriver2;
        private System.Windows.Forms.TextBox txtItinerary;
        private System.Windows.Forms.TextBox txtTurns;
        private System.Windows.Forms.TextBox txtBusNumber2;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button btnNew;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnRestore;
        private System.Windows.Forms.Button btnMinimize;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtDeparture1;
        private System.Windows.Forms.TextBox txtArrival1;
        private System.Windows.Forms.TextBox txtDeparture2;
        private System.Windows.Forms.TextBox txtArrival2;
    }
}