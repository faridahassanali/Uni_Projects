﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;
using System.Xml.Linq;

namespace STS
{
    public partial class newdatabuses : Form
    {
        string connstring = ConfigurationManager.ConnectionStrings["condb"].ConnectionString;
        public newdatabuses()
        {
            InitializeComponent();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
            newdata frm7 = new newdata();
            frm7.Show();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtExperience2_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtAddress2_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            txtBusNumber.Text = "";
            txtModel.Text = "";
            txtLicence.Text = "";
            txtCapacity.Text = "";
            txtAssgSupervisor.Text = "";
            txtAssgDriver.Text = "";
            txtMaintenance.Text = "";
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            using (SqlConnection connn = new SqlConnection(connstring))
            {
                connn.Open();
                string sqlll = "INSERT INTO Buses ([Bus number], [Model], [Licence plate number], [Capacity], [Maintenance history], [Assigned driver], [Assigned supervisor]) " +
                             "VALUES (@BusNumber, @Model, @Licence, @Capacity, @Maintenance, @AssgSupervisor, @AssgDriver)";
                using (SqlCommand cmddd = new SqlCommand(sqlll, connn))
                {
                    cmddd.Parameters.AddWithValue("@BusNumber", txtBusNumber.Text);
                    cmddd.Parameters.AddWithValue("@Model", txtModel.Text);
                    cmddd.Parameters.AddWithValue("@Licence", txtLicence.Text);
                    cmddd.Parameters.AddWithValue("@Maintenance", txtMaintenance.Text);
                    cmddd.Parameters.AddWithValue("@Capacity", txtCapacity.Text);
                    cmddd.Parameters.AddWithValue("@AssgSupervisor", txtAssgSupervisor.Text);
                    cmddd.Parameters.AddWithValue("@AssgDriver", txtAssgDriver.Text);

                    cmddd.ExecuteNonQuery();
                    MessageBox.Show("Record Added Successfully");
                }
            }

        }

        private void newdatabus_Enter(object sender, EventArgs e)
        {

        }

        private void newdatabuses_Load(object sender, EventArgs e)
        {

        }
    }
}
